# YAS-pedistrain-camera



# Install :-

git clone https://github.com/Hanysabeh/YAS-pedistrain-camera.git

cd YAS-pedistrain-camera

pip install -r requirements.txt

put any video for Zebra crossing road in the config folder 
then change the stream path in the config.json file or put the streaming path or connect a camera 



# Run :-

python profiler.py



